execute as @a[scores={deaths=1..}, tag=!got_myase] run advancement grant @s only card:myase

tag @s add got_myase