scoreboard players enable @a[tag=!hyper_player, tag=admin] hype

execute as @a[scores={hype=1..}] run give @s paper[custom_name='"Hyper Card"', custom_data={"card?":1b,card:"hyper"}, consumable={consume_seconds:0.05f, animation:"none", has_consume_particles:false, on_consume_effects:[]}]

execute as @a[scores={hype=1..}] run scoreboard players set @s hype 0