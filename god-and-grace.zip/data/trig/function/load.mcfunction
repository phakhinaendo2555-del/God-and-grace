scoreboard objectives add hype trigger
scoreboard objectives add class trigger
scoreboard objectives add traits trigger
scoreboard objectives add apply trigger
scoreboard objectives add deaths deathCount