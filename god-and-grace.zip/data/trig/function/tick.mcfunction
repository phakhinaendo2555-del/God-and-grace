function trig:classes_n_traits
function trig:hype
function trig:apply
function trig:death