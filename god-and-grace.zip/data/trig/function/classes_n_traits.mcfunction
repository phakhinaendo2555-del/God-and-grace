scoreboard players enable @a[tag=!apply] class
scoreboard players enable @a[tag=!apply] traits
scoreboard players enable @a[tag=!apply] apply