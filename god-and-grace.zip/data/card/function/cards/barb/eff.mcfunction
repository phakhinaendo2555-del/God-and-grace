function card:cards/barb/barb
schedule function card:cards/barb/eff 1t

clear @s paper[custom_data~{card:"ranger"}]
clear @s paper[custom_data~{card:"fighter"}]
clear @s paper[custom_data~{card:"rogue"}]
clear @s paper[custom_data~{card:"pala"}]
clear @s paper[custom_data~{card:"med"}]
clear @s paper[custom_data~{card:"mage"}]
clear @s paper[custom_data~{card:"pira"}]
clear @s paper[custom_data~{card:"undead"}]

advancement revoke @s[advancements={card:used=true}] only card:used