tag @s[tag=!barbarian] add barbarian

attribute @s[tag=barbarian, tag=!barb_set] attack_damage base set 18
attribute @s[tag=barbarian, tag=!barb_set] max_health base set 40
attribute @s[tag=barbarian, tag=!barb_set] scale base set 1.5

tag @s[tag=barbarian, tag=!barb_set] add barb_set

effect give @a[tag=barbarian] slowness 2 0 true