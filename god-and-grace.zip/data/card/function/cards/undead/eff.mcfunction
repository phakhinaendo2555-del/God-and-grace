function card:cards/undead/undead
schedule function card:cards/undead/eff 1t

clear @s paper[custom_data~{card:"ranger"}]
clear @s paper[custom_data~{card:"barbar"}]
clear @s paper[custom_data~{card:"fighter"}]
clear @s paper[custom_data~{card:"pala"}]
clear @s paper[custom_data~{card:"med"}]
clear @s paper[custom_data~{card:"mage"}]
clear @s paper[custom_data~{card:"rogue"}]
clear @s paper[custom_data~{card:"pira"}]

advancement revoke @s[advancements={card:used=true}] only card:used