tag @s[tag=!undead] add undead

execute if entity @s[tag=undead,tag=!undead_setup] run attribute @s minecraft:knockback_resistance base set 0.8
execute if entity @s[tag=undead,tag=!undead_setup] run attribute @s minecraft:max_health base set 30
execute if entity @s[tag=undead,tag=!undead_setup] run attribute @s minecraft:movement_speed base set 0.085
execute if entity @s[tag=undead,tag=!undead_setup] run attribute @s minecraft:submerged_mining_speed base set 1.0

tag @s[tag=undead] add undead_setup

execute as @a[tag=undead] at @s if predicate card:burn_in_sun run damage @s 1 minecraft:on_fire
effect clear @a[tag=undead] hunger
effect clear @a[tag=undead] poison