attribute @s attack_speed base set 6
attribute @s attack_damage base set 6

clear @s paper[custom_data~{card:"ranger"}]
clear @s paper[custom_data~{card:"barbar"}]
clear @s paper[custom_data~{card:"rogue"}]
clear @s paper[custom_data~{card:"pala"}]
clear @s paper[custom_data~{card:"med"}]
clear @s paper[custom_data~{card:"mage"}]
clear @s paper[custom_data~{card:"pira"}]
clear @s paper[custom_data~{card:"undead"}]

advancement revoke @s only card:used