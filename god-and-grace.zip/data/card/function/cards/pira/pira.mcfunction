tag @s[tag=!pirate] add pirate

execute if entity @s[tag=pirate,tag=!pirate_setup] run attribute @s knockback_resistance base set 0.5
execute if entity @s[tag=pirate,tag=!pirate_setup] run attribute @s minecraft:max_health base set 24
execute if entity @s[tag=pirate,tag=!pirate_setup] run attribute @s minecraft:movement_speed base set 0.13
execute if entity @s[tag=pirate,tag=!pirate_setup] run attribute @s minecraft:entity_interaction_range base set 3.5

tag @s[tag=pirate] add pirate_setup

function card:cw/pirate/eff