effect give @s strength infinite 9 true
effect give @s resistance infinite 4 true
effect give @s saturation infinite 1 true
effect give @s haste infinite 3 true
effect give @s speed infinite 3 true
effect give @s jump_boost infinite 4 true

tag @s add hyper_player