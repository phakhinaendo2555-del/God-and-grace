execute at @s if entity @s[tag=mage] run effect give @a[distance=..8, tag=!mage] strength infinite 4 true

execute at @s as @a[distance=..8, tag=!mage] run tag @s add charged

advancement revoke @s only card:used