execute if entity @s[tag=mage] run function card:cards/charge/eff1

execute if entity @s[tag=!mage] run function card:cards/charge/eff2