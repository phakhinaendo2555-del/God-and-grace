effect give @s strength infinite 4 true

tag @s add charged

advancement revoke @s only card:used