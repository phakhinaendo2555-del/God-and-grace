effect clear @s strength

tag @s remove charged
advancement revoke @s only card:dh