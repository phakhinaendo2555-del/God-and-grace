effect give @s jump_boost 40 3 true
effect give @s strength 40 4 true

advancement revoke @s only card:used