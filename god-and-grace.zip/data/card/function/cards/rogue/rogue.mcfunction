tag @s[tag=!rogue] add rogue

execute if entity @s[tag=rogue,tag=!rogue_setup] run attribute @s minecraft:movement_speed base set 0.14
execute if entity @s[tag=rogue,tag=!rogue_setup] run attribute @s minecraft:knockback_resistance base set 0.3
execute if entity @s[tag=rogue,tag=!rogue_setup] run attribute @s minecraft:luck base set 3
execute if entity @s[tag=rogue,tag=!rogue_setup] run attribute @s minecraft:attack_speed base set 6.0

execute if entity @s[tag=rogue,tag=!rogue_setup] run tag @s add rogue_setup

execute as @a[tag=rogue_setup] if predicate card:players_sneaking run effect give @s minecraft:invisibility 1 0 true