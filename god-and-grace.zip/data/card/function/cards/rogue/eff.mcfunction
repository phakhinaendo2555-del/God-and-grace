function card:cards/rogue/rogue
schedule function card:cards/rogue/eff 1t

clear @s paper[custom_data~{card:"ranger"}]
clear @s paper[custom_data~{card:"barbar"}]
clear @s paper[custom_data~{card:"fighter"}]
clear @s paper[custom_data~{card:"pala"}]
clear @s paper[custom_data~{card:"med"}]
clear @s paper[custom_data~{card:"mage"}]
clear @s paper[custom_data~{card:"pira"}]
clear @s paper[custom_data~{card:"undead"}]

advancement revoke @s[advancements={card:used=true}] only card:used