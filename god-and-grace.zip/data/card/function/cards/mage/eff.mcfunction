tag @s[tag=!mage] add mage

attribute @s minecraft:fall_damage_multiplier base set 0
attribute @s minecraft:luck base set 1024
attribute @s minecraft:movement_efficiency base set 1
attribute @s minecraft:water_movement_efficiency base set 1
attribute @s minecraft:scale base set 0.25
attribute @s minecraft:max_health base set 10

clear @s paper[custom_data~{card:"fighter"}]
clear @s paper[custom_data~{card:"barbar"}]
clear @s paper[custom_data~{card:"rogue"}]
clear @s paper[custom_data~{card:"pala"}]
clear @s paper[custom_data~{card:"med"}]
clear @s paper[custom_data~{card:"ranger"}]
clear @s paper[custom_data~{card:"pira"}]
clear @s paper[custom_data~{card:"undead"}]

advancement revoke @s only card:used