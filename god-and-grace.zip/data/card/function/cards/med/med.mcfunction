tag @s[tag=!medic] add medic

item replace entity @a[tag=medic] hotbar.6 with splash_potion[minecraft:potion_contents={potion:"minecraft:healing"}]