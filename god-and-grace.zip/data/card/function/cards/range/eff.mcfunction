attribute @s attack_speed base set 18
attribute @s sneaking_speed base set 1
attribute @s max_health base set 10
attribute @s scale base set 0.5

clear @s paper[custom_data~{card:"fighter"}]
clear @s paper[custom_data~{card:"barbar"}]
clear @s paper[custom_data~{card:"rogue"}]
clear @s paper[custom_data~{card:"pala"}]
clear @s paper[custom_data~{card:"med"}]
clear @s paper[custom_data~{card:"mage"}]
clear @s paper[custom_data~{card:"pira"}]
clear @s paper[custom_data~{card:"undead"}]

advancement revoke @s only card:used