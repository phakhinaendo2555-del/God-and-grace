tag @s[tag=!paladin] add paladin

execute as @a[tag=paladin] run effect give @s minecraft:hero_of_the_village 2 255 true

execute as @a[tag=paladin] run effect give @s minecraft:resistance 2 3 true

execute at @a if entity @a[tag=paladin] run effect give @a[distance=..8, tag=!paladin] minecraft:resistance 2 1 true