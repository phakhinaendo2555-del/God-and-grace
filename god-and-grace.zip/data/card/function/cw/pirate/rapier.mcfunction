give @s minecraft:iron_sword[minecraft:attribute_modifiers={modifiers:[{type:"minecraft:attack_damage",amount:6,operation:"add_value",id:"minecraft:rapier_damage"}]},custom_data={special:1b},custom_name='{"text":"Rapier"}'] 1

tag @s add pirate_armed