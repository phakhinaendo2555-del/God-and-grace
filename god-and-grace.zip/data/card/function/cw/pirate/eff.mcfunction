function card:cw/pirate/che
function card:cw/pirate/del
function card:cw/pirate/rod

schedule function card:cw/pirate/eff 1t