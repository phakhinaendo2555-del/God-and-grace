tag @s add apply

execute if score @s class matches 1 run function card:cards/fighter/eff
execute if score @s class matches 2 run function card:cards/range/eff
execute if score @s class matches 3 run function card:cards/rogue/eff
execute if score @s class matches 4 run function card:cards/mage/eff
execute if score @s class matches 5 run function card:cards/pala/eff
execute if score @s class matches 6 run function card:cards/pira/eff
execute if score @s class matches 7 run function card:cards/undead/eff
execute if score @s class matches 8 run function card:cards/barb/eff
execute if score @s class matches 9 run function card:cards/med/eff

execute if score @s traits matches 1 run function card:traits/strong/eff
execute if score @s traits matches 2 run function card:traits/la/eff
execute if score @s traits matches 3 run function card:traits/bei/eff
execute if score @s traits matches 4 run function card:traits/blessed/eff

trigger class add 0
trigger traits add 0
trigger apply add 0

clear @s written_book