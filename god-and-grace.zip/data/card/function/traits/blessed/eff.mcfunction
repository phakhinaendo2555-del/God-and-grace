tag @s add blessed
function card:traits/blessed/effect