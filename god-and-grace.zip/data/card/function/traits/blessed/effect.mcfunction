effect give @a[tag=blessed] minecraft:regeneration 1 2 true
effect give @a[tag=blessed] minecraft:fire_resistance 1 0 true
effect give @a[tag=blessed] minecraft:dolphins_grace 1 0 true

execute at @a[tag=blessed] as @e[type=#minecraft:undead,sort=nearest,limit=3, distance=..10] run damage @s 10

schedule function card:traits/blessed/effect 1t