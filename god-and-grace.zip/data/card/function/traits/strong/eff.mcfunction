tag @s add strong

function card:traits/strong/raod
function card:traits/strong/che

schedule function card:traits/strong/eff 1t