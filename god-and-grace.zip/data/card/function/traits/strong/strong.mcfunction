attribute @s minecraft:attack_damage modifier add f29b7d43-81ce-46a5-b092-37e6d1c854fa 0.5 add_multiplied_total

tag @s add st_set