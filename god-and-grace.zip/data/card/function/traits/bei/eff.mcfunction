tag @s add bei

effect clear @a[tag=bei] blindness
effect clear @a[tag=bei] darkness
effect clear @a[tag=bei] hunger
effect clear @a[tag=bei] infested
effect clear @a[tag=bei] mining_fatigue
effect clear @a[tag=bei] nausea
effect clear @a[tag=bei] oozing
effect clear @a[tag=bei] poison
effect clear @a[tag=bei] slowness
effect clear @a[tag=bei] weakness
effect clear @a[tag=bei] wither

schedule function card:traits/bei/eff 1t