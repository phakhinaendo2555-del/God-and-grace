attribute @s minecraft:entity_interaction_range modifier add 7b3e9a21-4f68-4c12-8d35-91a7e6b204f9 1 add_multiplied_base
attribute @s minecraft:block_interaction_range modifier add c84d15f7-2a93-47be-a601-53f9d8c72146 1 add_multiplied_base

tag @s add la_set