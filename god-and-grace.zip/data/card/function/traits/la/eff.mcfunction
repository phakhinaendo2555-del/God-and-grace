tag @s add la

function card:traits/la/raod
function card:traits/la/che

schedule function card:traits/la/eff 1t