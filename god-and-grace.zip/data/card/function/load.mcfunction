advancement revoke @a[tag=!hyper_player] only card:dh
advancement revoke @a[tag=!hyper_player] only card:used
scoreboard objectives add time minecraft.custom:minecraft.time_since_death