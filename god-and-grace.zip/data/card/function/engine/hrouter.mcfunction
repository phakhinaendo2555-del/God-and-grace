execute as @s[tag=Charged] run function card:cards/charge/end

execute as @s[tag=!Charged] run advancement revoke @s only card:dh