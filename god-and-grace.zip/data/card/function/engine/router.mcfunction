execute if items entity @s weapon.mainhand minecraft:paper[minecraft:custom_data~{card:"charge"}] run function card:cards/charge/che

execute if items entity @s weapon.offhand minecraft:paper[minecraft:custom_data~{card:"charge"}] run function card:cards/charge/che

execute if items entity @s weapon.mainhand minecraft:paper[minecraft:custom_data~{card:"hyper"}] run function card:cards/hyper/eff

execute if items entity @s weapon.offhand minecraft:paper[minecraft:custom_data~{card:"hyper"}] run function card:cards/hyper/eff

execute if items entity @s weapon.mainhand minecraft:paper[minecraft:custom_data~{card:"mace"}] run function card:cards/mace/che

execute if items entity @s weapon.offhand minecraft:paper[minecraft:custom_data~{card:"mace"}] run function card:cards/mace/che