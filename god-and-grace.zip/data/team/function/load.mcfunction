team add barbarian
team add rogue
team add pirate
team add undead
team add player