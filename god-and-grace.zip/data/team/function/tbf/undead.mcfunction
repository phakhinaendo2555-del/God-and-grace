team join undead @a[tag=undead]
team join undead @e[type=#minecraft:undead]