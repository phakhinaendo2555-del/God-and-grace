team join barbarian @a[tag=barbarian]
team join barbarian @e[type=hoglin]
team join barbarian @e[type=polar_bear]
team join barbarian @e[type=panda]