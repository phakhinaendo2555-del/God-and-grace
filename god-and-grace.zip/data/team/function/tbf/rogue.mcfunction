team join rogue @a[tag=rogue]
team join rogue @e[type=phantom]
team join rogue @e[type=enderman]