function team:tbf/pirate
function team:tbf/rogue
function team:tbf/undead
function team:tbf/barbarian